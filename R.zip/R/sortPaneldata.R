#' Sort Paneldata
#'
#' \code{sortPaneldata} sorts Panel data for the subject IDs,
#' followed by panel times. It relies on information given by
#' the user as to which columns are used.
#'
#' @param x dataframe
#'
#' @value Returns Dataframe sorted.



sortPaneldata <- function(base, panel){


  matrices <- list(base, panel)

 return(matrices)
}
